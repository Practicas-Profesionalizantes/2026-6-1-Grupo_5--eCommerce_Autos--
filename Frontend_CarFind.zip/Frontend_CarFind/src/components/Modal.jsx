import React, { useEffect } from 'react';

/**
 * Cuadro de diálogo genérico: se cierra con Escape o haciendo clic fuera.
 * @param {{ titulo: string, onCerrar: () => void, children: React.ReactNode }} props
 */
function Modal({ titulo, onCerrar, children }) {
  useEffect(() => {
    const onKeyDown = (e) => {
      if (e.key === 'Escape') onCerrar();
    };
    document.addEventListener('keydown', onKeyDown);
    return () => document.removeEventListener('keydown', onKeyDown);
  }, [onCerrar]);

  return (
    <div className="modal-backdrop" onClick={onCerrar}>
      <div
        className="modal-box"
        role="dialog"
        aria-modal="true"
        aria-label={titulo}
        onClick={(e) => e.stopPropagation()}
      >
        <h2 className="modal-title">{titulo}</h2>
        {children}
      </div>
    </div>
  );
}

export default Modal;

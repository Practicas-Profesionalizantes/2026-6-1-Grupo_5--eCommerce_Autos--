import React, { useSyncExternalStore } from 'react';
import { useNavigate } from 'react-router-dom';
import Logo from './Logo';
import { esTemaOscuro, aplicarTema, suscribirTema } from '../utils/tema';

function Header() {
    const navigate = useNavigate();
    // El tema ya viene aplicado desde main.jsx. Se lee con suscripción para que el ícono
    // también se actualice cuando el tema cambia desde Configuración > Apariencia o desde el sistema.
    const isDarkMode = useSyncExternalStore(suscribirTema, esTemaOscuro);

    const toggleTheme = () => aplicarTema(!isDarkMode);

    return (
        <header className="header">
            <Logo />
            
            <input className="search-bar" type="text" placeholder="Buscar auto..." />
            
            <div className="actions">
                <button onClick={toggleTheme} className="icon-button" title="Cambiar Tema">
                    {isDarkMode ? "🌙" : "☀️"}
                </button>
                <button className="icon-button" title="Lista de deseos" onClick={() => navigate("/wishlist")}>❤️</button>
                <button className="icon-button" title="Notificaciones">🔔</button>
                <button className="icon-button" title="Mensajes" onClick={() => navigate("/mensajes")}>💬</button>
                <button className="icon-button" title="Perfil" onClick={() => navigate("/perfil")}>👤</button>
            </div>

            <div className="login">
                <button className="navButton" onClick={() => navigate("/login")}>Iniciar Sesión</button>
                <button className="navButton" onClick={() => navigate("/register")}>Registrarse</button>
            </div>

            <div className='Configuracion'>
                <button className='icon-button' title="Configuración" onClick={() => navigate("/configuracion")}>⚙</button>
            </div>
        </header>
    );
}

export default Header;
import React from 'react';
import { Link } from 'react-router-dom';

/**
 * Tarjeta de una publicación del usuario en su perfil.
 * Se renderiza una vez por cada publicación asociada al usuario.
 * @param {{ publicacion: import('../types/perfil').PublicacionPerfilItem }} props
 */
function PublicacionPerfil({ publicacion }) {
  const { id, titulo, imagenUrl, disponible, likes, comentarios, compartidos } = publicacion;

  return (
    <article className="perfil-card">
      <Link to={`/publicacion/${id}`} className="perfil-card-image">
        <img src={imagenUrl} alt={titulo} />
      </Link>

      <div className="perfil-card-body">
        <h3 className="perfil-card-title">{titulo}</h3>

        <span className={`perfil-badge ${disponible ? 'perfil-badge--si' : 'perfil-badge--no'}`}>
          Disponible: {disponible ? 'Sí' : 'No'}
        </span>

        <ul className="perfil-interacciones">
          <li title="Likes" aria-label={`${likes} likes`}>❤️ {likes}</li>
          <li title="Comentarios" aria-label={`${comentarios} comentarios`}>💬 {comentarios}</li>
          <li title="Compartidos" aria-label={`${compartidos} compartidos`}>🔗 {compartidos}</li>
        </ul>
      </div>
    </article>
  );
}

export default PublicacionPerfil;

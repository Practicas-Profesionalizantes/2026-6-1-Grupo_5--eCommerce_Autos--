import React from 'react';
import { Link } from 'react-router-dom';

/**
 * Logo principal de CarFind (el mismo del Header). Lleva a la página de inicio.
 * @param {{ className?: string }} props  Clases extra para adaptarlo a cada contexto.
 */
function Logo({ className = '' }) {
  return (
    <div className={`logo ${className}`.trim()}>
      <Link to="/" style={{ textDecoration: 'none', color: 'inherit', fontWeight: 'bold' }}>
        CarFind
      </Link>
    </div>
  );
}

export default Logo;

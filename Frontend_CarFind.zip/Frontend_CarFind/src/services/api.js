/**
 * Cliente HTTP mínimo compartido por los servicios "api" (configuracionService.api.js).
 * perfilService.api.js todavía tiene su propia copia; se puede migrar a esta cuando convenga.
 *
 * Variables de entorno: VITE_API_URL (URL base del backend).
 */
const BASE_URL = import.meta.env.VITE_API_URL ?? '';

/** Cabecera de autenticación. Ajustar acá si la sesión se maneja distinto (cookie, otro nombre de token). */
const headersAuth = () => {
  const token = localStorage.getItem('token');
  return token ? { Authorization: `Bearer ${token}` } : {};
};

/**
 * @param {string} ruta                      Ej: "/configuracion"
 * @param {{ method?: string, json?: unknown, formData?: FormData }} [opciones]
 * @returns {Promise<any>} El JSON de la respuesta (null si es 204).
 */
export async function request(ruta, { method = 'GET', json, formData } = {}) {
  const headers = { ...headersAuth() };
  if (json) headers['Content-Type'] = 'application/json';

  const res = await fetch(`${BASE_URL}${ruta}`, {
    method,
    credentials: 'include',
    headers,
    body: formData ?? (json ? JSON.stringify(json) : undefined),
  });

  if (res.status === 401) {
    throw new Error('Tenés que iniciar sesión para continuar.');
  }
  if (!res.ok) {
    let mensaje;
    try {
      mensaje = (await res.json()).message;
    } catch {
      // la respuesta de error no era JSON
    }
    throw new Error(mensaje || `Error ${res.status}. Intentá de nuevo.`);
  }
  return res.status === 204 ? null : res.json();
}

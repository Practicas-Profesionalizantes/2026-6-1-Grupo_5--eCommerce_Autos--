/**
 * Cliente HTTP mínimo compartido por los servicios "api" (configuracionService.api.js).
 * perfilService.api.js todavía tiene su propia copia; se puede migrar a esta cuando convenga.
 *
 * Variables de entorno: VITE_API_URL (URL base del backend).
 */
const BASE_URL = import.meta.env.VITE_API_URL ?? '';

/** Cabecera de autenticación. Ajustar acá si la sesión se maneja distinto (cookie, otro nombre de token). */
const headersAuth = () => {
  const token = localStorage.getItem('token');
  return token ? { Authorization: `Bearer ${token}` } : {};
};

/**
 * @param {string} ruta                      Ej: "/configuracion"
 * @param {{ method?: string, json?: unknown, formData?: FormData }} [opciones]
 * @returns {Promise<any>} El JSON de la respuesta (null si es 204).
 */
export async function request(ruta, { method = 'GET', json, formData } = {}) {
  const headers = { ...headersAuth() };
  if (json) headers['Content-Type'] = 'application/json';

  const res = await fetch(`${BASE_URL}${ruta}`, {
    method,
    credentials: 'include',
    headers,
    body: formData ?? (json ? JSON.stringify(json) : undefined),
  });

  if (!res.ok) throw await errorDeRespuesta(res);
  return res.status === 204 ? null : res.json();
}

/** Arma el Error de una respuesta fallida. Lleva el código HTTP en `error.status` (ej: 401, 403). */
async function errorDeRespuesta(res) {
  let mensaje;
  if (res.status === 401) {
    mensaje = 'Tenés que iniciar sesión para continuar.';
  } else {
    try {
      mensaje = (await res.json()).message;
    } catch {
      // la respuesta de error no era JSON
    }
  }
  const error = new Error(mensaje || `Error ${res.status}. Intentá de nuevo.`);
  error.status = res.status;
  return error;
}

/**
 * Descarga un archivo del backend (informes en PDF o CSV).
 * @param {string} ruta
 * @returns {Promise<{ blob: Blob, nombreArchivo: string }>}  El nombre sale de la cabecera Content-Disposition.
 */
export async function requestBlob(ruta) {
  const res = await fetch(`${BASE_URL}${ruta}`, { credentials: 'include', headers: headersAuth() });
  if (!res.ok) throw await errorDeRespuesta(res);
  const disposicion = res.headers.get('Content-Disposition') ?? '';
  const nombreArchivo = /filename\*?=(?:UTF-8'')?"?([^";]+)"?/i.exec(disposicion)?.[1] ?? 'informe';
  return { blob: await res.blob(), nombreArchivo: decodeURIComponent(nombreArchivo) };
}

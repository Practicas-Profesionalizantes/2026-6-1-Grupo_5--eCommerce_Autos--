/**
 * Servicio de Publicaciones (detalle) — IMPLEMENTACIÓN MOCK.
 *
 * Para integrar el backend solo hay que reemplazar el cuerpo de getPublicacion
 * por una llamada real, manteniendo la forma de lo que devuelve:
 *   export const getPublicacion = (id) => api.get(`/publicaciones/${id}`);
 */
import { PUBLICACION_DETALLE_MOCK } from '../utils/mockPublicaciones';

const MOCK_DELAY_MS = 300;

/** Simula la latencia de red. */
const delay = (ms = MOCK_DELAY_MS) => new Promise((resolve) => setTimeout(resolve, ms));

/**
 * Devuelve el detalle de una publicación.
 * El mock devuelve siempre el mismo vehículo de ejemplo, pero con el id pedido.
 * @param {number|string} id
 * @returns {Promise<typeof PUBLICACION_DETALLE_MOCK>}
 */
export async function getPublicacion(id) {
  await delay();
  const numero = Number(id);
  if (!Number.isInteger(numero) || numero <= 0) {
    throw new Error('La publicación no existe.');
  }
  return { ...PUBLICACION_DETALLE_MOCK, id: numero };
}

/**
 * Resumen de una publicación (foto, título, disponibilidad e interacciones).
 * Lo usa la vista "Reportar publicación" para mostrar la tarjeta de lo que se reporta.
 * Contrato esperado: GET /publicaciones/:id/resumen → PublicacionPerfilItem (ver types/perfil.js)
 * @param {number|string} id
 * @returns {Promise<import('../types/perfil').PublicacionPerfilItem>}
 */
export async function getResumenPublicacion(id) {
  await delay();
  const numero = Number(id);
  if (!Number.isInteger(numero) || numero <= 0) {
    throw new Error('La publicación no existe.');
  }
  return {
    id: numero,
    titulo: PUBLICACION_DETALLE_MOCK.titulo,
    imagenUrl: PUBLICACION_DETALLE_MOCK.imagenes[0],
    disponible: true,
    likes: 24,
    comentarios: 6,
    compartidos: 3,
  };
}

/**
 * Servicio de Perfil — IMPLEMENTACIÓN REAL (backend).
 *
 * El usuario logueado lo identifica el backend (token o sesión), por eso ninguna
 * ruta lleva el id del usuario. Contrato esperado (formas en src/types/perfil.js):
 *
 *   GET    /perfil        → PerfilResponse            { usuario, publicaciones }
 *   POST   /perfil/foto   → { ok, usuario }           multipart/form-data, campo "foto"
 *   DELETE /perfil/foto   → { ok, usuario }
 *   PUT    /perfil        → { ok, usuario }           JSON con nombre, apellido, ubicacion, telefono
 *
 * Si el backend usa otros nombres de campo o rutas, se ajusta SOLO en este archivo.
 */

const BASE_URL = import.meta.env.VITE_API_URL ?? '';

/** Cabecera de autenticación. Ajustar acá si la sesión se maneja distinto (cookie, otro nombre de token). */
const headersAuth = () => {
  const token = localStorage.getItem('token');
  return token ? { Authorization: `Bearer ${token}` } : {};
};

/** Cliente mínimo. Si más adelante se completa services/api.js, se puede reemplazar por ese. */
async function request(ruta, { method = 'GET', json, formData } = {}) {
  const headers = { ...headersAuth() };
  if (json) headers['Content-Type'] = 'application/json';

  const res = await fetch(`${BASE_URL}${ruta}`, {
    method,
    credentials: 'include',
    headers,
    body: formData ?? (json ? JSON.stringify(json) : undefined),
  });

  if (res.status === 401) {
    throw new Error('Tenés que iniciar sesión para ver tu perfil.');
  }
  if (!res.ok) {
    let mensaje;
    try {
      mensaje = (await res.json()).message;
    } catch {
      // la respuesta de error no era JSON
    }
    throw new Error(mensaje || `Error ${res.status}. Intentá de nuevo.`);
  }
  return res.status === 204 ? null : res.json();
}

/** @returns {Promise<import('../types/perfil').PerfilResponse>} */
export const getPerfil = () => request('/perfil');

/**
 * @param {File} archivo
 * @returns {Promise<{ ok: boolean, usuario: import('../types/perfil').Perfil }>}
 */
export const subirFotoPerfil = (archivo) => {
  const formData = new FormData();
  formData.append('foto', archivo);
  return request('/perfil/foto', { method: 'POST', formData });
};

/** @returns {Promise<{ ok: boolean, usuario: import('../types/perfil').Perfil }>} */
export const eliminarFotoPerfil = () => request('/perfil/foto', { method: 'DELETE' });

/**
 * @param {import('../types/perfil').PerfilEditable} datos
 * @returns {Promise<{ ok: boolean, usuario: import('../types/perfil').Perfil }>}
 */
export const actualizarPerfil = (datos) => request('/perfil', { method: 'PUT', json: datos });

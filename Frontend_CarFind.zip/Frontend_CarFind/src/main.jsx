import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './assets/styles/variables.css'
import './assets/styles/preferencias.css'
import { BrowserRouter } from 'react-router-dom';
import App from './App.jsx'
import { aplicarTemaGuardado } from './utils/tema'
import { aplicarPreferenciasGuardadas } from './utils/preferenciasUI'

aplicarTemaGuardado()
aplicarPreferenciasGuardadas()

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <BrowserRouter>
      <App />
    </BrowserRouter>
  </StrictMode>
)